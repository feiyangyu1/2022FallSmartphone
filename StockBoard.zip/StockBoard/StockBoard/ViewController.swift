//
//  ViewController.swift
//  StockBoard
//
//  Created by macBook on 12/10/22.
//

import UIKit
import Alamofire
import SwiftyJSON
import SwiftSpinner
import PromiseKit

class ViewController: UIViewController , UITableViewDelegate, UITableViewDataSource{
   
    
    
    @IBOutlet weak var tblView: UITableView!
    var StockName = ""
    var StockNames = [""]
    var indexSelected = 0
   
    
    @IBOutlet weak var txtName: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        getStockValue(self)        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return StockNames.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = Bundle.main.loadNibNamed("FirstTableViewCell", owner: self)?.first as! FirstTableViewCell
        
       
        cell.firsttxtlabel?.text = StockNames[indexPath.row]

        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

           indexSelected = indexPath.row

           performSegue(withIdentifier: "segueSecondVC", sender: self)

       }
    
    @IBAction func sendName(_ sender: Any) {
        performSegue(withIdentifier: "segueSecondVC", sender: self)    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
           if segue.identifier == "segueSecondVC" {
               
               let secondVC = segue.destination as! SecondViewController
               
            let selectedStock = StockNames[indexSelected]

            secondVC.StockName = selectedStock["Symbol"].stringValue
           
                   // guard let name = txtName.text else {return}
               
          
           }
       }
    
    
    func getStockValue(_ sender: Any) {
           //let apiKey = "0ae8565c4294fa80d71b17b3ed6aca19"

           //var url = "https://financialmodelingprep.com/api/v3/quote/"
        var url = "https://us-central1-whatsapp-analytics-2de0e.cloudfunctions.net/app/allstocks"
          // url += txtSymbol.text!
           //url += "?apikey="
           //url += apiKey
        SwiftSpinner.show("Getting Stock Values")
               
               AF.request(url).responseJSON { responseData in
                  // print(responseData)
                   
                   SwiftSpinner.hide()
                   
                   if responseData.error != nil {
                       print(responseData.error!)
                       return
                   }
                
                let stockData = JSON(responseData.data as Any)

               guard let stock = JSON(responseData.data!).array else { return }

               // guard let stock = JSON(responseData.data!).array?.first else { return }
                
                
                for astock in stock{
               
               // print(astock["CompanyName"].stringValue)
                //print(astock["Price"].stringValue)
                               self.StockNames.append(astock["CompanyName"].stringValue + " " + astock["Symbol"].stringValue + " " + astock["Price"].stringValue)
                        self.tblView.reloadData()
                        
                    
                }
                

                
               
                
                
               }
       }
       }

