//
//  CompanyQuote.swift
//  StockBoard
//
//  Created by macBook on 12/10/22.
//

import Foundation

class CompanyQuote{
    var symbol : String = ""
    var name : String = ""
    var price : Float = 0.0
}
