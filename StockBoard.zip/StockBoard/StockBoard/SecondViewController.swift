//
//  SecondViewController.swift
//  StockBoard
//
//  Created by macBook on 12/10/22.
//

import UIKit
import Alamofire
import SwiftyJSON
import SwiftSpinner
import PromiseKit

class SecondViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{
    
    @IBOutlet weak var tblView: UITableView!
    var StockName = ""
    var StockNames = [""]
    override func viewDidLoad() {
        super.viewDidLoad()
       
        getStockValue(self)
        
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
        return StockNames.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = Bundle.main.loadNibNamed("StockTableViewCell", owner: self)?.first as! StockTableViewCell
        
       
        cell.txtLabel?.text = StockNames[indexPath.row]

        return cell
    }
    
    
    
    
    func getStockValue(_ sender: Any) {
           //let apiKey = "0ae8565c4294fa80d71b17b3ed6aca19"

           //var url = "https://financialmodelingprep.com/api/v3/quote/"
        var url = "https://us-central1-whatsapp-analytics-2de0e.cloudfunctions.net/app/allstocks"
          // url += txtSymbol.text!
           //url += "?apikey="
           //url += apiKey
        SwiftSpinner.show("Getting Stock Values")
               
               AF.request(url).responseJSON { responseData in
                  // print(responseData)
                   
                   SwiftSpinner.hide()
                   
                   if responseData.error != nil {
                       print(responseData.error!)
                       return
                   }
                
                let stockData = JSON(responseData.data as Any)

               guard let stock = JSON(responseData.data!).array else { return }

               // guard let stock = JSON(responseData.data!).array?.first else { return }
                
                
                for astock in stock{
               
               // print(astock["CompanyName"].stringValue)
                //print(astock["Price"].stringValue)
                    if astock["Symbol"].stringValue == self.StockName{                self.StockNames.append(astock["CompanyName"].stringValue + " " + astock["Symbol"].stringValue + " " + astock["Price"].stringValue)
                        self.tblView.reloadData()
                        
                    }
                }
                

                
               
                
                
               }
       }
       
     
           

       

}
