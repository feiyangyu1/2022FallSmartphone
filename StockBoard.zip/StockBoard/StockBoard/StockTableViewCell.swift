//
//  StockTableViewCell.swift
//  StockBoard
//
//  Created by macBook on 12/10/22.
//

import UIKit

class StockTableViewCell: UITableViewCell {
    @IBOutlet weak var txtLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
