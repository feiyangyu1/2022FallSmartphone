//
//  ForcastClass.swift
//  WeatherApp
//
//  Created by macBook on 11/19/22.
//

import Foundation

var temp: String = ""
var cloudcover: String = ""
var humidity: String = ""
var conditions: String = ""
