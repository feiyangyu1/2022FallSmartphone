//
//  ViewController.swift
//  WeatherApp
//
//  Created by macBook on 11/19/22.
//

import UIKit
import CoreLocation
import Alamofire
import SwiftyJSON
import SwiftSpinner


class ViewController: UIViewController, CLLocationManagerDelegate,UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var txtLocation: UITextField!
    let locationManager = CLLocationManager()
    var forcast = [""]
    var lon = 0
    var lat = 0
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return forcast.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = Bundle.main.loadNibNamed("ForcastTableViewCell", owner: self)?.first as! ForcastTableViewCell

        
        cell.temp.text = forcast[indexPath.row]
        //cell.textLabel?.text = forcast[indexPath.row] as! String


              return cell    }
    
    
    @IBAction func getForcast(_ sender: Any) {
        
        let locationStr = "\(self.lat),\(self.lon)"

        var url = "https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/weatherdata/forecast?locations="

        url += locationStr

        url += "&aggregateHours=24&unitGroup=us&shortColumnNames=false&contentType=json&key=AYQR6QM5KHFYVPH9M4EXXJUCC"

                AF.request(url).responseJSON { responseData in

                    //print(responseData)

                    if responseData.error != nil {

                        print(responseData.error!)

                        return

                    }

                    

                    let weatherData = JSON(responseData.data as Any)

                   // guard let stock = JSON(responseData.data!).array else { return }

                    let forecastValues =  weatherData["locations"][locationStr]["values"]

                    
                    if let forecastValues = weatherData.arrayObject as? [String] {
                        self.forcast = forecastValues
                    }


                    print(forecastValues.count)

                    

                    for forecast in forecastValues {

                        let forecastJSON = JSON(forecast.1)

                        let temp = forecastJSON["temp"].floatValue

                        print(forecast)

                     

                    }

                    

                                

                }
       
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters
        
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
            guard let location = locations.last else { return }
            
            let lat1 = location.coordinate.latitude
            let lng = location.coordinate.longitude
            
        lon = Int(lng)
        lat = Int(lat1)
        
           // lnglat = String(lng)+","+String(lat)
            
            
            print(lat)
            print(lng)
            
            getAddressFromLocation(location: location)
            
        }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
            print(error)
        }
        
   
    @IBAction func getLocation(_ sender: Any) {
        locationManager.requestLocation()
    }
    
    
    
    
        func getAddressFromLocation( location: CLLocation){
            
            let clGeoCoder = CLGeocoder()
            
            clGeoCoder.reverseGeocodeLocation(location) { placeMarks, error in
                
                if error != nil {
                    print(error?.localizedDescription)
                    return
                }
                var address = ""
                guard let place = placeMarks?.first else { return }
                
                if place.name != nil {
                    address += place.name! +  ", "
                }
                
                if place.locality != nil {
                    address += place.locality! +  ", "
                }
                if place.subLocality != nil {
                    address += place.subLocality! +  ", "
                }
                
                if place.postalCode != nil {
                    address += place.postalCode! +  ", "
                }
                
                if place.country != nil {
                    address += place.country!
                }
                
                //print(address)
                self.txtLocation.text = address
                
            }
        }
}

